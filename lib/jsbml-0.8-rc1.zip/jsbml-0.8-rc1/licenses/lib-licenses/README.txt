
Licenses for software used by JSBML
-------------------------------------------------------------------------------

This directory contains the licensing terms for software libraries that
JSBML depends upon and that is included in the JSBML distribution.  Please
note that the license files here are copies taken at a certain point in
time; in the event that there is a discrepancy between the license
statements included herein and the actual current licensing terms for a
given software library, the library's current license takes precedence.  In
no circumstance shall any author of JSBML, or their employer(s) or any
other individual(s) or group(s) associated with them, be liable in any way
due to a discrepancy in the stated licensing terms for a software library
included with JSBML.

The JSBML Project

-------------------------------------------------------------------------------
Date of last update to this file:
$Date: 2010-12-14 22:37:30 +0000 (Tue, 14 Dec 2010) $
$URL: https://jsbml.svn.sourceforge.net/svnroot/jsbml/branches/jsbml-0.8/licenses/lib-licenses/README.txt $
-------------------------------------------------------------------------------
